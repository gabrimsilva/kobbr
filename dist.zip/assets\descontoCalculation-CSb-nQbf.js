function r(r,e,t){if("valor"===e)return Number(r.toFixed(2));return Number((t*r/100).toFixed(2))}export{r as c};
